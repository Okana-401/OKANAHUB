import { User, Post, Comment, Notification } from '../types';

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Alex Morgan',
    username: 'alexmorgan',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Digital explorer. Coffee enthusiast. Always curious.',
    followers: 1234,
    following: 567,
  },
  {
    id: '2',
    name: 'Jordan Lee',
    username: 'jordanlee',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Photographer. Adventure seeker. Coffee addict.',
    followers: 4321,
    following: 432,
  },
  {
    id: '3',
    name: 'Riley Kim',
    username: 'rileykim',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Creative director. Art lover. City dweller.',
    followers: 8765,
    following: 345,
  },
  {
    id: '4',
    name: 'Taylor Smith',
    username: 'taylorsmith',
    avatar: 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Tech enthusiast. Fitness fanatic. Always learning.',
    followers: 3456,
    following: 234,
  },
  {
    id: '5',
    name: 'Avery Johnson',
    username: 'averyjohnson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Travel junkie. Food lover. Life explorer.',
    followers: 6789,
    following: 432,
  },
];

export const mockPosts: Post[] = [
  {
    id: '1',
    userId: '1',
    content: 'Just discovered this amazing coffee spot in Brooklyn! The ambiance is perfect for a productive afternoon. #CoffeeTime #BrooklynFinds',
    imageUrl: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=600',
    likes: 243,
    comments: 42,
    createdAt: '2025-01-20T14:30:00Z',
    isLiked: false,
  },
  {
    id: '2',
    userId: '2',
    content: 'Golden hour never disappoints. Captured this moment during my hike yesterday. #Photography #NatureLover',
    imageUrl: 'https://images.pexels.com/photos/1376201/pexels-photo-1376201.jpeg?auto=compress&cs=tinysrgb&w=600',
    likes: 789,
    comments: 65,
    createdAt: '2025-01-19T17:45:00Z',
    isLiked: true,
  },
  {
    id: '3',
    userId: '3',
    content: 'Currently working on a new art installation exploring the theme of interconnectedness. So excited to share it with you all soon!',
    likes: 453,
    comments: 31,
    createdAt: '2025-01-19T10:15:00Z',
    isLiked: false,
  },
  {
    id: '4',
    userId: '5',
    content: 'Tokyo sunrise from my hotel room. The city never sleeps, and neither did I. Worth every minute of jet lag. #TokyoAdventures #TravelLife',
    imageUrl: 'https://images.pexels.com/photos/1334605/pexels-photo-1334605.jpeg?auto=compress&cs=tinysrgb&w=600',
    likes: 1024,
    comments: 97,
    createdAt: '2025-01-18T21:30:00Z',
    isLiked: false,
  },
  {
    id: '5',
    userId: '4',
    content: 'Just finished reading this fascinating book on quantum computing. It's amazing how fast this field is evolving! #TechTalk #QuantumComputing',
    likes: 321,
    comments: 28,
    createdAt: '2025-01-18T16:20:00Z',
    isLiked: true,
  },
  {
    id: '6',
    userId: '1',
    content: 'Attended an inspiring talk on sustainable design yesterday. So many great ideas to implement in my next project! #SustainableDesign #Innovation',
    likes: 176,
    comments: 19,
    createdAt: '2025-01-17T13:10:00Z',
    isLiked: false,
  },
];

export const mockComments: Comment[] = [
  {
    id: '1',
    userId: '2',
    postId: '1',
    content: 'This place looks amazing! What's it called?',
    createdAt: '2025-01-20T14:45:00Z',
    likes: 12,
  },
  {
    id: '2',
    userId: '3',
    postId: '1',
    content: 'I need to check this out next time I'm in Brooklyn!',
    createdAt: '2025-01-20T15:20:00Z',
    likes: 8,
  },
  {
    id: '3',
    userId: '5',
    postId: '2',
    content: 'Stunning shot! What camera do you use?',
    createdAt: '2025-01-19T18:10:00Z',
    likes: 15,
  },
  {
    id: '4',
    userId: '1',
    postId: '4',
    content: 'Tokyo is on my bucket list! Any recommendations?',
    createdAt: '2025-01-18T22:05:00Z',
    likes: 7,
  },
];

export const mockNotifications: Notification[] = [
  {
    id: '1',
    userId: '1',
    type: 'like',
    actorId: '2',
    targetId: '1', // Post ID
    read: false,
    createdAt: '2025-01-20T15:30:00Z',
  },
  {
    id: '2',
    userId: '1',
    type: 'comment',
    actorId: '3',
    targetId: '1', // Post ID
    read: false,
    createdAt: '2025-01-20T15:20:00Z',
  },
  {
    id: '3',
    userId: '1',
    type: 'follow',
    actorId: '4',
    read: true,
    createdAt: '2025-01-19T09:15:00Z',
  },
  {
    id: '4',
    userId: '1',
    type: 'mention',
    actorId: '5',
    targetId: '5', // Post ID
    read: true,
    createdAt: '2025-01-18T14:40:00Z',
  },
];

// Helper function to get posts with user information
export const getPostsWithUsers = (): Post[] => {
  return mockPosts.map(post => ({
    ...post,
    user: mockUsers.find(user => user.id === post.userId)
  }));
};

// Helper function to get comments with user information
export const getCommentsWithUsers = (postId: string): Comment[] => {
  return mockComments
    .filter(comment => comment.postId === postId)
    .map(comment => ({
      ...comment,
      user: mockUsers.find(user => user.id === comment.userId)
    }));
};

// Helper function to get notifications with actor information
export const getNotificationsWithUsers = (userId: string): Notification[] => {
  return mockNotifications
    .filter(notification => notification.userId === userId)
    .map(notification => ({
      ...notification,
      actor: mockUsers.find(user => user.id === notification.actorId)
    }))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

export const getCurrentUser = (): User => {
  return mockUsers[0]; // Alex Morgan as the current user
};