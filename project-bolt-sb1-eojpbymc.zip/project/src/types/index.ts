export type User = {
  id: string;
  name: string;
  username: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
};

export type Post = {
  id: string;
  userId: string;
  user?: User; // Populated when displaying
  content: string;
  imageUrl?: string;
  likes: number;
  comments: number;
  createdAt: string;
  isLiked: boolean;
};

export type Comment = {
  id: string;
  userId: string;
  user?: User; // Populated when displaying
  postId: string;
  content: string;
  createdAt: string;
  likes: number;
};

export type Notification = {
  id: string;
  userId: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  actorId: string;
  actor?: User; // Populated when displaying
  targetId?: string; // Post or comment ID
  read: boolean;
  createdAt: string;
};