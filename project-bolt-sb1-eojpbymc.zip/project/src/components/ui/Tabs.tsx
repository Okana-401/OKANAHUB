import React, { useState } from 'react';

interface Tab {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface TabsProps {
  tabs: Tab[];
  defaultTabId?: string;
  onChange?: (tabId: string) => void;
  variant?: 'default' | 'pills' | 'bordered';
  className?: string;
}

const Tabs: React.FC<TabsProps> = ({
  tabs,
  defaultTabId,
  onChange,
  variant = 'default',
  className = '',
}) => {
  const [activeTab, setActiveTab] = useState(defaultTabId || tabs[0]?.id);

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
    if (onChange) {
      onChange(tabId);
    }
  };

  const getTabClassNames = (tabId: string) => {
    const isActive = activeTab === tabId;

    switch (variant) {
      case 'pills':
        return `px-4 py-2 rounded-full ${
          isActive
            ? 'bg-blue-500 text-white'
            : 'text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
        } transition-colors`;
      case 'bordered':
        return `px-4 py-2 ${
          isActive
            ? 'border-b-2 border-blue-500 text-blue-500 font-medium'
            : 'text-gray-700 dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400'
        } transition-colors`;
      default:
        return `px-4 py-2 ${
          isActive
            ? 'text-blue-500 font-medium'
            : 'text-gray-700 dark:text-gray-200 hover:text-blue-500 dark:hover:text-blue-400'
        } transition-colors`;
    }
  };

  return (
    <div className={`flex ${className}`}>
      {tabs.map((tab) => (
        <button
          key={tab.id}
          className={`flex items-center gap-2 ${getTabClassNames(tab.id)}`}
          onClick={() => handleTabClick(tab.id)}
          aria-selected={activeTab === tab.id}
          role="tab"
        >
          {tab.icon && <span>{tab.icon}</span>}
          <span>{tab.label}</span>
        </button>
      ))}
    </div>
  );
};

export default Tabs;