import React from 'react';
import Tabs from '../ui/Tabs';
import { Sparkles, Clock } from 'lucide-react';

interface FeedFiltersProps {
  activeFilter: string;
  onChange: (filter: string) => void;
}

const FeedFilters: React.FC<FeedFiltersProps> = ({ activeFilter, onChange }) => {
  const filters = [
    { id: 'trending', label: 'Trending', icon: <Sparkles size={16} /> },
    { id: 'latest', label: 'Latest', icon: <Clock size={16} /> },
  ];

  return (
    <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 py-4 mb-6 sticky top-16 z-10 transition-colors duration-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <Tabs 
          tabs={filters} 
          defaultTabId={activeFilter}
          onChange={onChange}
          variant="pills"
        />
      </div>
    </div>
  );
};

export default FeedFilters;