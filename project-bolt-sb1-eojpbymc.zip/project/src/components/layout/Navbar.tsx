import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { getCurrentUser } from '../../data/mockData';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import { Bell, Home, Search, User, LogOut, Sun, Moon, Menu, X, MessageCircle } from 'lucide-react';

const Navbar: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const currentUser = getCurrentUser();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery);
    // In a real app, we would trigger a search action here
  };

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm sticky top-0 z-50 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and brand */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <span className="text-2xl font-bold text-blue-500">Okanahub</span>
            </div>
          </div>

          {/* Search bar - hide on mobile */}
          <div className="hidden md:block flex-1 max-w-md mx-8">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search Okanahub..."
                  className="w-full bg-gray-100 dark:bg-gray-800 border-0 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </form>
          </div>

          {/* Nav items - desktop */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="p-2 text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
              <Home size={24} />
            </button>
            <button className="p-2 text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
              <MessageCircle size={24} />
            </button>
            <button className="p-2 text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 relative">
              <Bell size={24} />
              <span className="absolute top-0 right-0 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">3</span>
            </button>
            <button className="p-2 text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800">
              <User size={24} />
            </button>
            <button 
              className="p-2 text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
              onClick={toggleTheme}
            >
              {theme === 'dark' ? <Sun size={24} /> : <Moon size={24} />}
            </button>
            <div className="pl-2 border-l border-gray-200 dark:border-gray-700">
              <Avatar src={currentUser.avatar} alt={currentUser.name} size="sm" />
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="flex md:hidden">
            <button
              onClick={toggleMenu}
              className="p-2 rounded-md text-gray-600 dark:text-gray-300 hover:text-blue-500 dark:hover:text-blue-400 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`md:hidden transition-all duration-300 ease-in-out ${isMenuOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0 invisible'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white dark:bg-gray-900 shadow-lg">
          <div className="p-2">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search Okanahub..."
                className="w-full bg-gray-100 dark:bg-gray-800 border-0 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex items-center p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800">
            <Home size={20} className="mr-3 text-gray-500 dark:text-gray-400" />
            <span>Home</span>
          </div>

          <div className="flex items-center p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800">
            <MessageCircle size={20} className="mr-3 text-gray-500 dark:text-gray-400" />
            <span>Messages</span>
          </div>

          <div className="flex items-center p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800">
            <Bell size={20} className="mr-3 text-gray-500 dark:text-gray-400" />
            <span>Notifications</span>
            <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">3</span>
          </div>

          <div className="flex items-center p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800">
            <User size={20} className="mr-3 text-gray-500 dark:text-gray-400" />
            <span>Profile</span>
          </div>

          <div className="flex items-center p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800" onClick={toggleTheme}>
            {theme === 'dark' ? (
              <>
                <Sun size={20} className="mr-3 text-gray-500 dark:text-gray-400" />
                <span>Light Mode</span>
              </>
            ) : (
              <>
                <Moon size={20} className="mr-3 text-gray-500 dark:text-gray-400" />
                <span>Dark Mode</span>
              </>
            )}
          </div>

          <div className="pt-2 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center p-2">
              <Avatar src={currentUser.avatar} alt={currentUser.name} size="sm" />
              <div className="ml-3">
                <div className="font-medium">{currentUser.name}</div>
                <div className="text-sm text-gray-500 dark:text-gray-400">@{currentUser.username}</div>
              </div>
            </div>
            <div className="flex items-center p-2 text-red-500 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800">
              <LogOut size={20} className="mr-3" />
              <span>Sign Out</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;