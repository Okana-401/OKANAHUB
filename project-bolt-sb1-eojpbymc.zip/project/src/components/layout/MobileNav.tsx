import React from 'react';
import { Home, User, MessageCircle, Bell, PlusCircle } from 'lucide-react';

const MobileNav: React.FC = () => {
  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 z-40 transition-colors duration-200">
      <div className="flex justify-around">
        <a href="#" className="flex flex-col items-center py-3 text-blue-500">
          <Home size={24} />
          <span className="text-xs mt-1">Home</span>
        </a>
        <a href="#" className="flex flex-col items-center py-3 text-gray-500 dark:text-gray-400">
          <User size={24} />
          <span className="text-xs mt-1">Profile</span>
        </a>
        <a href="#" className="flex flex-col items-center py-3">
          <div className="-mt-6 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 p-3 shadow-lg">
            <PlusCircle size={24} className="text-white" />
          </div>
          <span className="text-xs mt-1 text-gray-500 dark:text-gray-400">Post</span>
        </a>
        <a href="#" className="flex flex-col items-center py-3 text-gray-500 dark:text-gray-400">
          <MessageCircle size={24} />
          <span className="text-xs mt-1">Messages</span>
        </a>
        <a href="#" className="flex flex-col items-center py-3 text-gray-500 dark:text-gray-400 relative">
          <Bell size={24} />
          <span className="absolute top-2 right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">3</span>
          <span className="text-xs mt-1">Alerts</span>
        </a>
      </div>
    </nav>
  );
};

export default MobileNav;