import React from 'react';
import { Home, User, Users, Bookmark, Settings, MessageCircle, Bell, LogOut } from 'lucide-react';
import { getCurrentUser } from '../../data/mockData';
import Avatar from '../ui/Avatar';

const Sidebar: React.FC = () => {
  const currentUser = getCurrentUser();

  const navItems = [
    { icon: <Home size={24} />, label: 'Home', active: true },
    { icon: <User size={24} />, label: 'Profile' },
    { icon: <MessageCircle size={24} />, label: 'Messages' },
    { icon: <Bell size={24} />, label: 'Notifications', badge: 3 },
    { icon: <Users size={24} />, label: 'Friends' },
    { icon: <Bookmark size={24} />, label: 'Saved' },
    { icon: <Settings size={24} />, label: 'Settings' },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 h-[calc(100vh-64px)] sticky top-16 transition-colors duration-200">
      <div className="flex-1 overflow-y-auto pt-5 pb-4">
        <nav className="mt-5 px-2 space-y-2">
          {navItems.map((item, index) => (
            <a
              key={index}
              href="#"
              className={`group flex items-center px-4 py-3 text-gray-700 dark:text-gray-200 rounded-lg ${
                item.active
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400'
                  : 'hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <span className={`${item.active ? 'text-blue-500' : 'text-gray-500 dark:text-gray-400 group-hover:text-blue-500'}`}>
                {item.icon}
              </span>
              <span className="ml-3 font-medium">{item.label}</span>
              {item.badge && (
                <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {item.badge}
                </span>
              )}
            </a>
          ))}
        </nav>
      </div>

      <div className="p-4 border-t border-gray-200 dark:border-gray-800">
        <div className="flex items-center">
          <Avatar src={currentUser.avatar} alt={currentUser.name} size="sm" />
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-200">{currentUser.name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">@{currentUser.username}</p>
          </div>
        </div>
        <button className="mt-4 flex items-center justify-center w-full px-4 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-lg transition-colors">
          <LogOut size={16} className="mr-2" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;