import React from 'react';
import Card, { CardBody } from '../ui/Card';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import { User } from '../../types';
import { getCurrentUser } from '../../data/mockData';

const ProfileCard: React.FC = () => {
  const user = getCurrentUser();

  return (
    <Card className="mb-6">
      <div className="h-24 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-t-xl"></div>
      <CardBody className="-mt-12 flex flex-col items-center">
        <Avatar src={user.avatar} alt={user.name} size="xl" className="ring-4 ring-white dark:ring-gray-800" />
        <h2 className="mt-2 text-xl font-bold text-gray-900 dark:text-white">{user.name}</h2>
        <p className="text-gray-500 dark:text-gray-400">@{user.username}</p>
        <p className="mt-2 text-center text-gray-600 dark:text-gray-300">{user.bio}</p>
        
        <div className="mt-4 w-full flex justify-around text-center">
          <div>
            <div className="font-bold text-gray-900 dark:text-white">{user.followers.toLocaleString()}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Followers</div>
          </div>
          <div className="border-l border-gray-200 dark:border-gray-700"></div>
          <div>
            <div className="font-bold text-gray-900 dark:text-white">{user.following.toLocaleString()}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Following</div>
          </div>
        </div>
        
        <Button
          variant="outline"
          fullWidth
          className="mt-4"
        >
          Edit Profile
        </Button>
      </CardBody>
    </Card>
  );
};

export default ProfileCard;