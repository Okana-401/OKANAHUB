import React from 'react';
import Card, { CardBody, CardHeader } from '../ui/Card';
import { TrendingUp } from 'lucide-react';

const trendingTopics = [
  {
    tag: 'TechConference2025',
    posts: 15432,
    category: 'Technology',
  },
  {
    tag: 'SummerFestival',
    posts: 12876,
    category: 'Entertainment',
  },
  {
    tag: 'ClimateSolutions',
    posts: 8765,
    category: 'Environment',
  },
  {
    tag: 'ArtificialIntelligence',
    posts: 7689,
    category: 'Technology',
  },
  {
    tag: 'WorldCupFinals',
    posts: 6543,
    category: 'Sports',
  },
];

const TrendingTopics: React.FC = () => {
  return (
    <Card className="mb-6">
      <CardHeader className="flex items-center">
        <TrendingUp className="w-5 h-5 text-blue-500 mr-2" />
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Trending Topics</h2>
      </CardHeader>
      <CardBody className="pt-0">
        <ul className="divide-y divide-gray-200 dark:divide-gray-700">
          {trendingTopics.map((topic, index) => (
            <li key={index} className="py-3 hover:bg-gray-50 dark:hover:bg-gray-800 -mx-4 px-4 transition-colors cursor-pointer">
              <div className="text-xs text-gray-500 dark:text-gray-400 mb-1">{topic.category}</div>
              <div className="font-semibold text-gray-900 dark:text-white">#{topic.tag}</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">{topic.posts.toLocaleString()} posts</div>
            </li>
          ))}
        </ul>
      </CardBody>
    </Card>
  );
};

export default TrendingTopics;