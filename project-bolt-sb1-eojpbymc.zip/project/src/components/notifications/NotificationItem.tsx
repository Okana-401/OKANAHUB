import React from 'react';
import { Heart, MessageCircle, UserPlus, AtSign } from 'lucide-react';
import { Notification } from '../../types';
import Avatar from '../ui/Avatar';
import { formatTimeAgo } from '../../utils/dateUtils';

interface NotificationItemProps {
  notification: Notification;
  onMarkAsRead: (id: string) => void;
}

const NotificationItem: React.FC<NotificationItemProps> = ({ notification, onMarkAsRead }) => {
  const getIcon = () => {
    switch (notification.type) {
      case 'like':
        return <Heart size={16} className="text-red-500" />;
      case 'comment':
        return <MessageCircle size={16} className="text-blue-500" />;
      case 'follow':
        return <UserPlus size={16} className="text-green-500" />;
      case 'mention':
        return <AtSign size={16} className="text-purple-500" />;
      default:
        return null;
    }
  };

  const getMessage = () => {
    const actorName = notification.actor?.name || 'Someone';
    
    switch (notification.type) {
      case 'like':
        return <span><span className="font-medium">{actorName}</span> liked your post</span>;
      case 'comment':
        return <span><span className="font-medium">{actorName}</span> commented on your post</span>;
      case 'follow':
        return <span><span className="font-medium">{actorName}</span> started following you</span>;
      case 'mention':
        return <span><span className="font-medium">{actorName}</span> mentioned you in a post</span>;
      default:
        return 'New notification';
    }
  };

  return (
    <div 
      className={`p-4 flex items-start gap-3 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition-colors ${
        !notification.read ? 'bg-blue-50 dark:bg-blue-900/10' : ''
      }`}
      onClick={() => onMarkAsRead(notification.id)}
    >
      <div className="rounded-full p-2 bg-gray-100 dark:bg-gray-800">
        {getIcon()}
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="text-gray-900 dark:text-white">
              {getMessage()}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              {formatTimeAgo(notification.createdAt)}
            </div>
          </div>
          
          <Avatar 
            src={notification.actor?.avatar || ''} 
            alt={notification.actor?.name || ''} 
            size="sm"
          />
        </div>
      </div>
      
      {!notification.read && (
        <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0"></div>
      )}
    </div>
  );
};

export default NotificationItem;