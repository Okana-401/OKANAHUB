import React, { useState } from 'react';
import { Heart, MessageCircle, Share2, MoreHorizontal, Send } from 'lucide-react';
import { Post } from '../../types';
import Avatar from '../ui/Avatar';
import Card, { CardBody, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import { formatTimeAgo } from '../../utils/dateUtils';

interface PostCardProps {
  post: Post;
}

const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const [isLiked, setIsLiked] = useState(post.isLiked);
  const [likesCount, setLikesCount] = useState(post.likes);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');

  const handleLike = () => {
    if (isLiked) {
      setLikesCount(likesCount - 1);
    } else {
      setLikesCount(likesCount + 1);
    }
    setIsLiked(!isLiked);
  };

  const handleCommentToggle = () => {
    setShowComments(!showComments);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      console.log('Comment submitted:', commentText);
      // In a real app, we would add the comment to the database
      setCommentText('');
    }
  };

  return (
    <Card className="mb-4">
      <CardBody className="pb-3">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Avatar src={post.user?.avatar || ''} alt={post.user?.name || ''} size="sm" />
            <div className="ml-3">
              <div className="font-medium text-gray-900 dark:text-white">{post.user?.name}</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">
                @{post.user?.username} • {formatTimeAgo(post.createdAt)}
              </div>
            </div>
          </div>
          <button className="text-gray-400 hover:text-gray-500">
            <MoreHorizontal size={20} />
          </button>
        </div>

        <div className="mb-4">
          <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">{post.content}</p>
        </div>

        {post.imageUrl && (
          <div className="mb-4 -mx-4 sm:-mx-0 sm:rounded-lg overflow-hidden">
            <img
              src={post.imageUrl}
              alt="Post image"
              className="w-full object-cover max-h-[500px]"
              loading="lazy"
            />
          </div>
        )}

        <div className="flex items-center justify-between text-gray-500 dark:text-gray-400 pt-2">
          <div className="flex items-center">
            <button
              className={`flex items-center mr-4 ${isLiked ? 'text-red-500' : 'hover:text-red-500'} transition-colors`}
              onClick={handleLike}
            >
              <Heart size={20} className={isLiked ? 'fill-current' : ''} />
              <span className="ml-2 text-sm">{likesCount}</span>
            </button>
            <button 
              className="flex items-center hover:text-blue-500 transition-colors"
              onClick={handleCommentToggle}
            >
              <MessageCircle size={20} />
              <span className="ml-2 text-sm">{post.comments}</span>
            </button>
          </div>
          <button className="flex items-center hover:text-green-500 transition-colors">
            <Share2 size={20} />
          </button>
        </div>
      </CardBody>

      {showComments && (
        <CardFooter className="pt-0 border-t-0">
          <form onSubmit={handleCommentSubmit} className="w-full">
            <div className="flex items-center">
              <Avatar
                src={post.user?.avatar || ''}
                alt="Your avatar"
                size="xs"
                className="mr-2"
              />
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="flex-1 bg-gray-100 dark:bg-gray-800 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Button
                type="submit"
                variant="ghost"
                className="ml-2"
                disabled={!commentText.trim()}
              >
                <Send size={18} />
              </Button>
            </div>
          </form>
        </CardFooter>
      )}
    </Card>
  );
};

export default PostCard;