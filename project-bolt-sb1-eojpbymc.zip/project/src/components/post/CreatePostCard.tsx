import React, { useState } from 'react';
import { Image, MapPin, Smile, X } from 'lucide-react';
import Card, { CardBody, CardFooter } from '../ui/Card';
import Avatar from '../ui/Avatar';
import Button from '../ui/Button';
import { getCurrentUser } from '../../data/mockData';

const CreatePostCard: React.FC = () => {
  const [postContent, setPostContent] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const currentUser = getCurrentUser();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (postContent.trim() || selectedImage) {
      console.log('Creating post:', { content: postContent, image: selectedImage });
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        setPostContent('');
        setSelectedImage(null);
        setIsSubmitting(false);
      }, 1000);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setSelectedImage(event.target.result as string);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
  };

  return (
    <Card className="mb-6">
      <form onSubmit={handleSubmit}>
        <CardBody>
          <div className="flex items-start">
            <Avatar src={currentUser.avatar} alt={currentUser.name} size="md" />
            <div className="ml-3 flex-1">
              <textarea
                placeholder="What's on your mind?"
                className="w-full border-0 focus:ring-0 text-lg text-gray-800 dark:text-white bg-transparent resize-none min-h-[80px]"
                value={postContent}
                onChange={(e) => setPostContent(e.target.value)}
              />
              
              {selectedImage && (
                <div className="relative mt-2 rounded-lg overflow-hidden">
                  <img src={selectedImage} alt="Selected" className="max-h-[300px] w-auto" />
                  <button
                    type="button"
                    className="absolute top-2 right-2 bg-gray-800 bg-opacity-50 text-white rounded-full p-1 hover:bg-opacity-70"
                    onClick={removeImage}
                  >
                    <X size={16} />
                  </button>
                </div>
              )}
            </div>
          </div>
        </CardBody>
        
        <CardFooter className="flex flex-wrap items-center justify-between">
          <div className="flex space-x-2">
            <label className="p-2 text-gray-500 hover:text-blue-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer">
              <Image size={20} />
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleImageChange}
              />
            </label>
            <button
              type="button"
              className="p-2 text-gray-500 hover:text-amber-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              <Smile size={20} />
            </button>
            <button
              type="button"
              className="p-2 text-gray-500 hover:text-red-500 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              <MapPin size={20} />
            </button>
          </div>
          <Button
            type="submit"
            disabled={(!postContent.trim() && !selectedImage) || isSubmitting}
            isLoading={isSubmitting}
          >
            Post
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default CreatePostCard;